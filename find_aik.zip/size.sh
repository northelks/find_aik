#!/bin/bash

cat lib/main.dart | wc -c